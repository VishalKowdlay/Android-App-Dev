package com.example.spinnerdemo;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    TextView textView;
    Button button;
    Spinner spinner;
    ArrayList<String> list;
    EditText editText;
    int pos;
    String temp1 = "";
    //Practice: put in button to make it processes adding, make nothing selected method work, make button click make onNothingSelected method work (google the cases)
    //1. edit text that adds whatever to spinner, figure out nothing selected method to work when button pressed

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textView = findViewById(R.id.id_text);
        button = findViewById(R.id.id_button);
        spinner = findViewById(R.id.id_spin);
        editText = findViewById(R.id.id_edit);

        list = new ArrayList<>();
        /*list.add("Jim");
        list.add("Bob");
        list.add("Billy");
        list.add("Jene");
        list.add("Jen");

        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<>(this, R.layout.support_simple_spinner_dropdown_item, list);//don't need identifier type in <>,
        // parentheses needs context this, layout spinner, and ArrayList list
        spinner.setAdapter(arrayAdapter);
        //temp1 = editText.getText().toString();*/

        addOption("");
        pos = 0;


        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(editText.getText().toString().isEmpty()) {
                    spinner.setSelection(0);
                    pos = 0;
                    textView.setText("NONE");
                }
                else addOption(editText.getText().toString());

            }
        });

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {//do set item then type "O" in ()
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                textView.setText(list.get(position));
                pos = position;
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                textView.setText("NONE");
            }
        });

    }
    public void addOption(String temp)
    {
        list.add(temp);
        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<>(this, R.layout.support_simple_spinner_dropdown_item, list);//don't need identifier type in <>,
        spinner.setAdapter(arrayAdapter);
        spinner.setSelection(pos);

    }

}