package com.example.widgetsday1demo1;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.SeekBar;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    TextView textSeek;
    SeekBar seekBar;
    

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textSeek = findViewById(R.id.id_text_seek);
        seekBar = findViewById(R.id.id_seek);

        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {//all methods for seekBar by typing .setOnSeek and .OnSeek
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                textSeek.setText(""+progress+"%");
                boolean hasStopped = true;

            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                textSeek.setText("START");

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                textSeek.setText("STOP");
                int value = seekBar.getProgress();

            }
        });

    }
}