package com.example.lifecycledemo;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    Button b;
    int i = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Log.d("TAG", "onCreate");
        b = findViewById(R.id.button);

        if (savedInstanceState != null)
            i = savedInstanceState.getInt("KEY1");//set this up
        b.setText("Value " + i);

        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                i++;
                b.setText("Value " + i);
            }
        });

    }
    @Override
    protected void onStart(){
        super.onStart();
        Log.d("TAG", "start");
    }

    @Override
    protected void onResume(){
        super.onResume();
        Log.d("TAG", "resume");
    }

    @Override
    protected void onStop(){
        super.onStop();
        Log.d("TAG", "stop");
    }

    @Override
    protected void onDestroy(){
        super.onDestroy();
        Log.d("TAG", "destroy");
    }

    @Override
    protected void onPause(){
        super.onPause();
        Log.d("TAG", "pause");
    }
}