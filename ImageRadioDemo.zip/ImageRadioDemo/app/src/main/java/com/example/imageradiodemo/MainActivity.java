package com.example.imageradiodemo;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.RadioGroup;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    ImageView imageView;
    RadioGroup radioGroup;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        imageView = findViewById(R.id.imageView2);
        radioGroup = findViewById(R.id.radioGroup);
        //put all RadioButtons in RadioGroup so only one gets selected
        //copy the icon versions of the images, download them and name w/ letters and underscores
        //copy paste them into res -> drawable folders and put the image in both the drawable and drawable v24 folders

        imageView.setImageResource(R.drawable.darth_vader);
        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                if(checkedId == R.id.radioButton2) {
                    //do stuff
                    Toast myMessage = Toast.makeText(MainActivity.this, "Don't Fall Asleep", Toast.LENGTH_SHORT); /*context that states the activity its in, string message, Toast length method*/
                    myMessage.show();//show the message!
                }
            }
        });


    }
}